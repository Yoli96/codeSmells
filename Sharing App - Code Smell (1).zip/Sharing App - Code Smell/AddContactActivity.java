﻿package com.example.sharingapp;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
public class AddContactActivity extends AppCompatActivity {
private ContactList contact_list = new ContactList();
private ContactListController contact_list_controller = new ContactListController(contact_list);private Context context;private EditText username;private String username_str;private String email_str;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact);
        username = (EditText) findViewById(R.id.username);
        email = (EditText) findViewById(R.id.email);
        context = getApplicationContext();
        contact_list_controller.loadContacts(context);
    }
}
